self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c7f5da315c95899ed6e07d479cf0faeb",
    "url": "/index.html"
  },
  {
    "revision": "1cc1bdb71487e787e3d7",
    "url": "/static/css/2.c9730596.chunk.css"
  },
  {
    "revision": "ac66c832c56b85e14ed0",
    "url": "/static/css/main.b5c68997.chunk.css"
  },
  {
    "revision": "1cc1bdb71487e787e3d7",
    "url": "/static/js/2.f128fd19.chunk.js"
  },
  {
    "revision": "ac66c832c56b85e14ed0",
    "url": "/static/js/main.e055b097.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "4c1aa73be44c89586effe6f64723717e",
    "url": "/static/media/cart1.4c1aa73b.png"
  },
  {
    "revision": "158162f6df18f83b8da60997fe8d2594",
    "url": "/static/media/cart2.158162f6.png"
  },
  {
    "revision": "049760c431fc9539fd6141f1f48a2c3d",
    "url": "/static/media/map.049760c4.png"
  },
  {
    "revision": "cfa3d6df6c0f527a3eb1a4e79325c3c3",
    "url": "/static/media/show.cfa3d6df.png"
  },
  {
    "revision": "532a5cbfc41cad002be47047f9184de3",
    "url": "/static/media/spring.532a5cbf.png"
  },
  {
    "revision": "9b199fec4e94192ff6db1e9d582dc6cf",
    "url": "/static/media/图层 2.9b199fec.png"
  },
  {
    "revision": "b9fa919c430b7775682e32054caf345a",
    "url": "/static/media/图层8.b9fa919c.png"
  },
  {
    "revision": "a4ae7cb0144f01f60020b6bc5b139818",
    "url": "/static/media/底.a4ae7cb0.png"
  },
  {
    "revision": "0a0bb116af8e59fcd8ed4f163f0bf830",
    "url": "/static/media/照片.0a0bb116.png"
  }
]);